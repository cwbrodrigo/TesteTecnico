SELECT * from Cliente as c
INNER JOIN Financiamento as f on c.IdCliente = f.IdCliente
INNER JOIN Pagamento as p on p.IdCliente = c.IdCliente
where f.ParcelasPagas = f.ParcelasPagas * 0.6 and c.UF = 'SP';

SELECT TOP 4 c.* from Cliente as c
INNER JOIN Financiamento as f ON c.IdCliente = f.IdCliente
INNER JOIN Pagamento as p ON c.IdCliente = p.IdCliente
where p.DataPagamento < DATEADD(DAY, 5, f.DataVencimento) and p.DataPagamento IS NULL;

SELECT * FROM Cliente as c
INNER JOIN Financiamento as f ON c.IdCliente = f.IdCliente
INNER JOIN Pagamento as p ON c.IdCliente = p.IdCliente
where p.DataPagamento < DATEADD(DAY, 10, f.DataVencimento) and f.ValorTotal > 10000;