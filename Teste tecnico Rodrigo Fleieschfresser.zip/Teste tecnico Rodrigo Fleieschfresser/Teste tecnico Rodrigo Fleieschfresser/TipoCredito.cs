﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste_tecnico_Rodrigo_Fleieschfresser
{
    public enum TipoCredito
    {
        CreditoDireto = 1, 
        CreditoConsignado = 2,
        CreditoPessoaJudirica = 3,
        CreditoPessoaFisica = 4,
        CreditoImobiliario = 5
    }
}
