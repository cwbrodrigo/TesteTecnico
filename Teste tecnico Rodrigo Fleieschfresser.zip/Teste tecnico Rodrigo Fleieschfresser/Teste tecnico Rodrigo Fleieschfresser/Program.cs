﻿using Teste_tecnico_Rodrigo_Fleieschfresser;

public class TesteRodrigo
{

    static void Main(string[] args)
    {
        TipoCredito tipoCredito = new TipoCredito();
        
        Console.WriteLine("Escolha o tipo de credito - 1: CreditoDireto - 2: CreditoConsignado - 3: CreditoPessoaJudirica - 4: CreditoPessoaFisica - 5: CreditoImobiliario");
        
        tipoCredito = (TipoCredito)Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Escolha o valor do credito: R$");

        double valorCredito = 0;

        valorCredito = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Escolha o número de parcelas: ");

        int parcelas = 0;

        parcelas = Convert.ToInt32(Console.ReadLine());

        Simular(valorCredito, tipoCredito, 18, DateTime.Now.AddDays(17));
    }

    public static void Simular(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        bool valido = true;
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;
        bool dataValida = false;

        if (ValorCredito > 1000000 || parcelas < 5 || parcelas > 72)
        {
            valido = false;
            StatusCredito = "Reprovado";
        }

        if (vencimento >= DateTime.Now.AddDays(15) && vencimento <= DateTime.Now.AddDays(40))
            dataValida = true;

        if (tipoCredito == TipoCredito.CreditoPessoaJudirica && ValorCredito < 15000)
            ValidarPessoaJudirica(ValorCredito, tipoCredito, parcelas, vencimento);

        if (valido && dataValida)
        {
            if (tipoCredito == TipoCredito.CreditoDireto)
                ValidaCreditoDireto(ValorCredito, tipoCredito, parcelas, vencimento);

            else if (tipoCredito == TipoCredito.CreditoConsignado)
                ValidaCreditoConsignado(ValorCredito, tipoCredito, parcelas, vencimento);

            else if (tipoCredito == TipoCredito.CreditoPessoaFisica)
                ValidaCreditoPessoaFisica(ValorCredito, tipoCredito, parcelas, vencimento);

            else if (tipoCredito == TipoCredito.CreditoImobiliario)
                ValidaCreditoImobiliario(ValorCredito, tipoCredito, parcelas, vencimento);
        }
        else
        {
            StatusCredito = "Reprovado";

            Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
            Console.ReadKey();
        }

    }

    public static void ValidarPessoaJudirica(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;

        if (tipoCredito == TipoCredito.CreditoPessoaJudirica && ValorCredito < 15000)
        {
            double percentual = 0.05;
            percentual = percentual * parcelas;
            double valorParcial = ValorCredito + (percentual * ValorCredito);
            Juros = ValorCredito * percentual * parcelas;
            ValorTotal = valorParcial + Juros;

            StatusCredito = "Aprovado";
        }
        else
            StatusCredito = "Reprovado";

        Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
        Console.ReadKey();
    }

    public static void ValidaCreditoDireto(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;

        double percentual = 0.02;
        double valorParcial = ValorCredito + (percentual * ValorCredito);
        Juros = valorParcial * percentual * parcelas;
        ValorTotal = valorParcial + Juros;

        StatusCredito = "Aprovado";

        Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
        Console.ReadKey();
    }

    public static void ValidaCreditoConsignado(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;

        double percentual = 0.01;
        percentual = percentual * parcelas;
        double valorParcial = ValorCredito + (percentual * ValorCredito);
        Juros = ValorCredito * percentual * parcelas;
        ValorTotal = valorParcial + Juros;

        StatusCredito = "Aprovado";

        Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
        Console.ReadKey();
    }

    public static void ValidaCreditoPessoaFisica(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;

        double percentual = 0.03;
        percentual = percentual * parcelas;
        double valorParcial = ValorCredito + (percentual * ValorCredito);
        Juros = ValorCredito * percentual * parcelas;
        ValorTotal = valorParcial + Juros;

        StatusCredito = "Aprovado";

        Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
        Console.ReadKey();
    }

    public static void ValidaCreditoImobiliario(double ValorCredito, TipoCredito tipoCredito, int parcelas, DateTime vencimento)
    {
        double ValorTotal = 0;
        double Juros = 0;
        string StatusCredito = string.Empty;

        double percentual = 0.09;
        percentual = percentual * parcelas;
        double valorParcial = ValorCredito + (percentual * ValorCredito);
        Juros = ValorCredito * percentual * parcelas;
        ValorTotal = valorParcial + Juros;

        StatusCredito = "Aprovado";

        Console.WriteLine("Status do crédito: " + StatusCredito + " Valor Total: " + ValorTotal + " Juros: " + Juros.ToString());
        Console.ReadKey();
    }
}